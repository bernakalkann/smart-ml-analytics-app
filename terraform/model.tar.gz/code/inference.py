import os
import json
import torch
import torch.nn as nn
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# FastAPI uygulamasındaki ile tamamen aynı model tanımı
class PredictionModel(nn.Module):
    def __init__(self, input_dim: int = 4, output_dim: int = 1):
        super(PredictionModel, self).__init__()
        self.network = nn.Sequential(
            nn.Linear(input_dim, 16),
            nn.ReLU(),
            nn.Linear(16, 8),
            nn.ReLU(),
            nn.Linear(8, output_dim)
        )
        
    def forward(self, x):
        return self.network(x)

def model_fn(model_dir):
    """
    S3'ten indirilip açılan model.pt dosyasını yükler.
    """
    logger.info("model_fn: Loading model weights from disk...")
    # Model kaydedilirken doğrudan nn.Sequential olarak kaydedildiği için 
    # burada da doğrudan eşleşen Sequential yapısını tanımlıyoruz.
    model = nn.Sequential(
        nn.Linear(4, 16),
        nn.ReLU(),
        nn.Linear(16, 8),
        nn.ReLU(),
        nn.Linear(8, 1)
    )
    model_path = os.path.join(model_dir, "model.pt")
    
    # Ağırlıkları yükle
    model.load_state_dict(torch.load(model_path, map_location=torch.device('cpu')))
    model.eval()
    logger.info("model_fn: Model successfully loaded.")
    return model

def input_fn(request_body, request_content_type):
    """
    İstemciden gelen JSON isteğini işler ve PyTorch tensor formatına çevirir.
    """
    logger.info(f"input_fn: Received request with content type: {request_content_type}")
    if request_content_type == 'application/json':
        request_data = json.loads(request_body)
        features = request_data.get('features', [])
        
        # Girdiyi tensor'a çevir
        return torch.tensor([features], dtype=torch.float32)
    else:
        raise ValueError(f"Unsupported content type: {request_content_type}")

def predict_fn(input_data, model):
    """
    Model çıkarım (inference) işlemini yürütür.
    """
    logger.info("predict_fn: Performing inference...")
    with torch.no_grad():
        prediction = model(input_data)
    return prediction

def output_fn(prediction, content_type):
    """
    Tahmin sonucunu JSON olarak formatlayıp istemciye döner.
    """
    logger.info("output_fn: Formatting model response...")
    if content_type == 'application/json':
        prediction_val = prediction.item()
        return json.dumps({
            "prediction": prediction_val,
            "model_version": "v1.0.0"
        }), 'application/json'
    else:
        raise ValueError(f"Unsupported content type: {content_type}")
